const express = require("express");
const bodyParser = require("body-parser");
const { MongoClient } = require("mongodb");
const fs = require("fs");


const app = express();
const PORT = 3000;
const path = require("path");

app.use(express.static(__dirname));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static("public"));



// MongoDB Connection
const client = new MongoClient("mongodb://localhost:27017");

// Register Route
app.post("/register", async (req, res) => {
    try {
        await client.connect();

        const db = client.db("royalenfield");
        const collection = db.collection("users");

        const user = {
            fullname: req.body.fullname,
            email: req.body.email,
            password: req.body.password
        };

        // Validation
        if (
            user.fullname === "" ||
            user.email === "" ||
            user.password === ""
        ) {
            return res.send("All fields are required");
        }

        await collection.insertOne(user);

        fs.writeFile(
            "userlog.txt",
            `Registered User: ${user.fullname}\nEmail: ${user.email}`,
            (err) => {
                if (err) throw err;
                console.log("Data saved in file");
            }
        );

        console.log("User Registered");

        res.redirect("/sm.html");

    } catch (err) {
        console.log(err);
        res.send("Registration Failed");
    }
});

// Login Route
app.post("/login", async (req, res) => {
    try {
        await client.connect();

        const db = client.db("royalenfield");
        const collection = db.collection("users");

        const user = await collection.findOne({
            email: req.body.email,
            password: req.body.password
        });

        if (user) {
            console.log("Login Success");
            res.redirect("/home.html");
        } else {
            res.send("Invalid Email or Password");
        }

    } catch (err) {
        console.log(err);
        res.send("Login Failed");
    }
});

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "sm.html"));
});

app.listen(PORT, () => {
    console.log(`Server Running at http://localhost:${PORT}`);
});